﻿namespace Server
{
	public interface IServer
	{
		void Start(int playersCount);
	}
}