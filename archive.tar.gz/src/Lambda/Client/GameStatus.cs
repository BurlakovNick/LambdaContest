﻿namespace Client
{
	public enum GameStatus
	{
		Handshake,
		Setup,
		Gameplay
	}
}