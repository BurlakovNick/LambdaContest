﻿namespace Core.Objects
{
    public class Node
    {
        public int Id { get; set; }
        public bool IsMine { get; set; }
    }
}