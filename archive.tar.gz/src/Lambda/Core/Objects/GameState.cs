﻿namespace Core.Objects
{
    public class GameState
    {
        public Map Map { get; set; }
        public Punter CurrentPunter { get; set; }
    }
}