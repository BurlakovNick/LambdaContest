﻿namespace Core.Objects
{
    public class Game
    {
    }
}