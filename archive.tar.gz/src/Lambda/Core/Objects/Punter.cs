﻿namespace Core.Objects
{
    public class Punter
    {
        public int Id { get; set; }
    }
}