﻿using Core.Objects;

namespace Core
{
    public class ShortestDistance
    {
        public Node From { get; set; }
        public Node To { get; set; }
        public int Length { get; set; }
    }
}