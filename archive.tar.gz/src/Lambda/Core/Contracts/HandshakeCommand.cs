﻿namespace Core.Contracts
{
	public class HandshakeCommand
	{
		public string me { get; set; }
	}
}