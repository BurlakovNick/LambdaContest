﻿namespace Core.Contracts
{
	public class SiteContract
	{
		public int id { get; set; }
	}
}