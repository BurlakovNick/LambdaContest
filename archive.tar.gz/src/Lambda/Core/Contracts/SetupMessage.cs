﻿namespace Core.Contracts
{
	public class SetupMessage
	{
		public int punter { get; set; }
		public int punters { get; set; }
		public MapContract map { get; set; }
	}
}