﻿namespace Core.Contracts
{
	public class RiverContract
	{
		public int source { get; set; }
		public int target { get; set; }
	}
}