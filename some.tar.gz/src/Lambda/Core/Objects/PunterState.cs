﻿namespace Core.Objects
{
    public class PunterState
    {
    }
}