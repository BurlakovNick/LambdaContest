﻿namespace Core.Contracts
{
	public class HandshakeMessage
	{
		public string you { get; set; }
	}
}