﻿namespace Core.Contracts
{
	public class Pass
	{
		public int punter { get; set; }
	}
}