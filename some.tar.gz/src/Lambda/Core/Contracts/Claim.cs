﻿namespace Core.Contracts
{
	public class Claim
	{
		public int punter { get; set; }
		public int source { get; set; }
		public int target { get; set; }
	}
}