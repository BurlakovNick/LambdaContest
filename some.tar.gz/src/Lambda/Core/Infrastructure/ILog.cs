namespace Core
{
	public interface ILog
	{
		void Log(string message);
	}
}